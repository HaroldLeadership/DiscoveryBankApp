package co.za.discovery.banking.DiscoveryATM.repository;

import co.za.discovery.banking.DiscoveryATM.model.ATMAllocation;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import javax.transaction.Transactional;
import java.util.List;

public interface ATMAllocationRepository extends JpaRepository<ATMAllocation, Integer> {
        List<ATMAllocation> findAllByAtmID (Integer atmID);

        @Modifying(clearAutomatically = true)
        @Transactional
        @Query("UPDATE ATMAllocation c SET c.count = :count WHERE c.atmID = :atmID AND c.denominationID = :denominationID")
        int updateATMAllocation(@Param("count") int count, @Param("atmID") int atmID, @Param("denominationID") int denominationID);

}
