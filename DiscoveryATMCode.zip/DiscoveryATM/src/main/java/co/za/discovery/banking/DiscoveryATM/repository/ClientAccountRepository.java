package co.za.discovery.banking.DiscoveryATM.repository;

import co.za.discovery.banking.DiscoveryATM.model.ClientAccount;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import javax.transaction.Transactional;
import java.util.List;

@Repository
public interface ClientAccountRepository extends JpaRepository<ClientAccount, String> {

    @Query("select a from ClientAccount a where a.clientID = :clientID order by a.displayBalance desc")
    List<ClientAccount> findAllByClientIDOrderByDisplayBalance (@Param("clientID") Integer clientID);

    @Query("select a from ClientAccount a where a.clientAccountNumber = :clientAccountNumber")
    ClientAccount findClientAccountByClientAccountNumber(@Param("clientAccountNumber") String clientAccountNumber);

    @Modifying(clearAutomatically = true)
    @Transactional
    @Query("UPDATE ClientAccount c SET c.displayBalance = :amount WHERE c.clientAccountNumber = :accountNumber")
    int updateClientAccount(@Param("amount") Double amount, @Param("accountNumber") String accountNumber);
}
