package co.za.discovery.banking.DiscoveryATM;

import co.za.discovery.banking.DiscoveryATM.model.*;
import co.za.discovery.banking.DiscoveryATM.pojo.Account;
import co.za.discovery.banking.DiscoveryATM.pojo.Errors;
import co.za.discovery.banking.DiscoveryATM.pojo.WithdrawCash;
import co.za.discovery.banking.DiscoveryATM.service.BankAppServiceImpl;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;
import java.util.List;

@Controller
public class BankingAppController extends BankAppServiceImpl {

    @GetMapping("/")
    public String atm(Model model) {
        List <ATM> atmList = getATMList();
        model.addAttribute("atms", atmList);
        return  "atms";
    }

    @GetMapping("/login")
    public String login(@RequestParam("param") String atmID,Model model, HttpSession session) {
        Login login = new Login();

        ATM atm = getATM(stringToInteger(atmID));
        login.setAtm(atm);
        session.setAttribute("atm", atm);
        model.addAttribute("login", login);
        return  "login";
    }

    @PostMapping("/login")
    public String submitLogon (@Valid Login logon, BindingResult bindingResult, HttpSession session){

        if (bindingResult.hasErrors()) {
            return "login";
        }

        if (authenticate(logon)) {
            session.setAttribute("userinfo", logon);
            return "index";
        } else {
            bindingResult.rejectValue("clientID", "notFound", "Client ID not found");
            return "login";
        }
    }

    @GetMapping ("/index")
    public String index(HttpSession session) {
        Object object = session.getAttribute("userinfo");

        if(object == null){
            return "login";
        }
        return  "index";
    }

    @GetMapping ("/results")
    public String results() {
        return  "results";
    }

    @GetMapping ("/transactionalaccounts")
    public String transactionalAccounts(Model model, HttpSession session) {
        Login login = (Login)session.getAttribute("userinfo");
        List<Account> clientAccountList = getClientTransactionalAccount(login);

        setErrorMessages(model, clientAccountList);
        model.addAttribute("transactionalaccounts", clientAccountList);

        return  "transactionalaccounts";
    }

    @GetMapping ("/currencyaccounts")
    public String currencyAccounts(Model model, HttpSession session) {
        Login login = (Login)session.getAttribute("userinfo");
        List<Account> clientCurrencyAccountsList = getClientCurrencyAccount(login);

        setErrorMessages(model, clientCurrencyAccountsList);
        model.addAttribute("currencyaccounts", clientCurrencyAccountsList);

        return  "currencyaccounts";
    }

    @GetMapping ("/withdraw")
    public String withdraw(Model model, HttpSession session) {
        Login login = (Login)session.getAttribute("userinfo");
        List<Account> clientAccountsList = getClientTransactionalAccount(login);

        setErrorMessages(model, clientAccountsList);
        model.addAttribute("withdraw", clientAccountsList);

        return  "withdraw";
    }

    @GetMapping ("/withdrawcash")
    public String withdrawCash(@RequestParam("param") String accountNumber, Model model) {
        WithdrawCash withdrawCash = getClientAccount (accountNumber);
        model.addAttribute("withdrawcash", withdrawCash);

        return  "withdrawcash";
    }

    @PostMapping("/withdrawavailable")
    public String withdrawAvailableCash (@ModelAttribute WithdrawCash withdrawalAccount, Model model, HttpSession session){
        return withdrawCash (withdrawalAccount, model, session);
    }

    @PostMapping("/withdrawcash")
    public String withdrawCash (@ModelAttribute WithdrawCash withdrawalAccount, Model model, HttpSession session){

        Double requestedAmount = withdrawalAccount.getRequestedAmount();
        Double currentBalance = withdrawalAccount.getCurrentBalance();

        // Determine if the requested amount is available for withdrawal
        if ((currentBalance == 0.0) || (currentBalance < requestedAmount)) {
            setErrorMessages(model, "Insufficient funds");
            model.addAttribute("error", withdrawalAccount);
            return "negativeresults";
        }

        // Determine the credit limit for Credit Accounts
        if(withdrawalAccount.getAcountTypeCode().equals("CCRD")){
            if(checkCreditLimit(withdrawalAccount.getAccountNumber(), requestedAmount)){
                setErrorMessages(model, "Credit Limit Exceeded");
                model.addAttribute("error", withdrawalAccount);
                return "negativeresults";
            }
        }

        if(requestedAmount%10!=0){
            setErrorMessages(model, "Please enter the amount in multiples of 10");
            model.addAttribute("error", withdrawalAccount);
            return "negativeresults";
        }

        ATM atm = (ATM)session.getAttribute("atm");
        Double availableAtmCash = calcTotalNotes(atm.getAtmID());
        // Determine if ATM have enough cash to dispense the required amount

        if(availableAtmCash == 0.00){
            setErrorMessages(model, "Amount not available, please try again later.");
            model.addAttribute("error", withdrawalAccount);
            return "negativeresults";
        }

        if(requestedAmount > availableAtmCash){
            setErrorMessages(model, "Amount not available, would you like to draw R"+availableAtmCash+"?");
            model.addAttribute("availableCash", availableAtmCash);
            model.addAttribute("requestedAmount", withdrawalAccount.getRequestedAmount());
            withdrawalAccount.setRequestedAmount(availableAtmCash);
            model.addAttribute("error", withdrawalAccount);
            return "withdrawavailable";
        }

        WithdrawCash updatedAccount = cashWithdrawal(withdrawalAccount, atm);
        model.addAttribute("updatedAccount", updatedAccount);

        return  "results";
    }

    private void setErrorMessages(Model model, List<Account> clientAccountList){
        Errors errors = new Errors();

        if(clientAccountList.size() == 0){
            errors.setErrorMessage("No accounts to display");
            model.addAttribute("errors", errors);
        }else{
            errors.setErrorMessage("");
            model.addAttribute("errors", errors);
        }
    }

    private void setErrorMessages(Model model, String message){
        Errors errors = new Errors();
        errors.setErrorMessage(message);
        model.addAttribute("errors", errors);
    }
}
