package co.za.discovery.banking.DiscoveryATM.service;

import java.util.ArrayList;
import java.util.List;

public class WithDrawService {

    private static final WithDrawService instance = new WithDrawService();

    public static WithDrawService getInstance() {
        return instance;
    }

    protected List<Integer[]> determineDenomination(int[] values, int[] amounts, int[] variation, int price, int position){
        List<Integer[]> list = new ArrayList<>();
        int value = compute(values, variation);
        if (value < price){
            for (int i = position; i < values.length; i++) {
                if (amounts[i] > variation[i]){
                    int[] newvariation = variation.clone();
                    newvariation[i]++;
                    List<Integer[]> newList = determineDenomination(values, amounts, newvariation, price, i);
                    if (newList != null){
                        list.addAll(newList);
                    }
                }
            }
        } else if (value == price) {
            list.add(myCopy(variation));
        }
        return list;
    }

    protected int compute(int[] values, int[] variation){
        int ret = 0;
        for (int i = 0; i < variation.length; i++) {
            ret += values[i] * variation[i];
        }
        return ret;
    }

    protected Integer[] myCopy(int[] ar){
        Integer[] ret = new Integer[ar.length];
        for (int i = 0; i < ar.length; i++) {
            ret[i] = ar[i];
        }
        return ret;
    }

    protected Integer [] getLowestNotes (List<Integer[]> notes, int size){
        Integer [] lowest = new Integer[size];
        int prevsCount = 0;
        int currtCount = 0;
        for (Integer[] result : notes){
            for(int k = 0; k < result.length; k++){
                currtCount += result[k];
            }

            if (prevsCount == 0 && currtCount > 0){
                prevsCount = currtCount;
                lowest = result;
            }else if(currtCount < prevsCount){
                prevsCount = currtCount;
                lowest = result;
            }else {
                prevsCount = currtCount;
            }
            currtCount = 0;
        }

        return lowest;
    }
}
