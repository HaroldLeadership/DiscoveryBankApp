package co.za.discovery.banking.DiscoveryATM.repository;

import co.za.discovery.banking.DiscoveryATM.model.CreditCardLimit;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CreditCardLimitRepository extends JpaRepository <CreditCardLimit, String> {

    CreditCardLimit findCreditCardLimitByClientAccountNumber(String accountNumber);
}
