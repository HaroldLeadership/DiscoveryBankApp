package co.za.discovery.banking.DiscoveryATM.model;

import javax.persistence.*;

@Entity
@Table(name = "CLIENT_ACCOUNT")
public class ClientAccount {

   @Id
   @Column(name = "CLIENT_ACCOUNT_NUMBER", nullable = false)
   private String clientAccountNumber;

   @Column(name = "CLIENT_ID", nullable = false)
   private int clientID;

   @Column(name = "ACCOUNT_TYPE_CODE", nullable = false)
   private String accountTypeCode;

   @Column(name = "CURRENCY_CODE", nullable = false)
   private String currencyCode;

   @Column(name = "DISPLAY_BALANCE", nullable = false)
   private Double displayBalance;

   @ManyToOne
   @JoinColumn (name = "CLIENT_ID", nullable = false,insertable = false, updatable = false)
   private Client client;

    @OneToOne(fetch = FetchType.LAZY,optional=false)
    @JoinColumn(name = "ACCOUNT_TYPE_CODE",nullable = false, insertable=false, updatable=false)
    private AccountType accountType;

    @OneToOne(fetch = FetchType.LAZY, optional=false)
    @JoinColumn( name = "CURRENCY_CODE", nullable = false,insertable=false, updatable=false)
    private Currency currency;

    @OneToOne(fetch = FetchType.LAZY, optional=false)
    @JoinColumn( name = "CLIENT_ACCOUNT_NUMBER", nullable = false,insertable=false, updatable=false)
    private CreditCardLimit creditCardLimit;

    public String getClientAccountNumber() {
        return clientAccountNumber;
    }

    public void setClientAccountNumber(String clientAccountNumber) {
        this.clientAccountNumber = clientAccountNumber;
    }

    public int getClientID() {
        return clientID;
    }

    public void setClientID(int clientID) {
        this.clientID = clientID;
    }

    public String getAccountTypeCode() {
        return accountTypeCode;
    }

    public void setAccountTypeCode(String accountTypeCode) {
        this.accountTypeCode = accountTypeCode;
    }

    public String getCurrencyCode() {
        return currencyCode;
    }

    public void setCurrencyCode(String currencyCode) {
        this.currencyCode = currencyCode;
    }

    public Double getDisplayBalance() {
        return displayBalance;
    }

    public void setDisplayBalance(Double displayBalance) {
        this.displayBalance = displayBalance;
    }

    public Client getClient() {
        return client;
    }

    public void setClient(Client client) {
        this.client = client;
    }

    public AccountType getAccountType() {
        return accountType;
    }

    public void setAccountType(AccountType accountType) {
        this.accountType = accountType;
    }

    public Currency getCurrency() {
        return currency;
    }

    public void setCurrency(Currency currency) {
        this.currency = currency;
    }

    public CreditCardLimit getCreditCardLimit() {
        return creditCardLimit;
    }

    public void setCreditCardLimit(CreditCardLimit creditCardLimit) {
        this.creditCardLimit = creditCardLimit;
    }

    @Override
    public String toString() {
        return "\nClientAccount{" +
                "clientAccountNumber='" + clientAccountNumber + '\'' +
                ", clientID=" + clientID +
                ", accountTypeCode='" + accountTypeCode + '\'' +
                ", currencyCode='" + currencyCode + '\'' +
                ", displayBalance=" + displayBalance +
                ", accountType=" + accountType +
                ", currency=" + currency +
                '}';
    }
}
