package co.za.discovery.banking.DiscoveryATM.pojo;

import java.sql.Timestamp;

public class WithdrawCash {

    private String acountType;
    private String acountTypeCode;
    private String accountNumber;
    private Double currentBalance;
    private Double requestedAmount;
    private Timestamp timestamp;
    private Double previousBalance;
    private String notes;

    public String getAcountType() {
        return acountType;
    }

    public void setAcountType(String acountType) {
        this.acountType = acountType;
    }

    public String getAcountTypeCode() {
        return acountTypeCode;
    }

    public void setAcountTypeCode(String acountTypeCode) {
        this.acountTypeCode = acountTypeCode;
    }

    public String getAccountNumber() {
        return accountNumber;
    }

    public void setAccountNumber(String accountNumber) {
        this.accountNumber = accountNumber;
    }

    public Double getCurrentBalance() {
        return currentBalance;
    }

    public void setCurrentBalance(Double currentBalance) {
        this.currentBalance = currentBalance;
    }

    public Double getRequestedAmount() {
        return requestedAmount;
    }

    public void setRequestedAmount(Double requestedAmount) {
        this.requestedAmount = requestedAmount;
    }

    public Double getPreviousBalance() {
        return previousBalance;
    }

    public void setPreviousBalance(Double previousBalance) {
        this.previousBalance = previousBalance;
    }

    public String getNotes() {
        return notes;
    }

    public void setNotes(String notes) {
        this.notes = notes;
    }

    public Timestamp getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(Timestamp timestamp) {
        this.timestamp = timestamp;
    }

    @Override
    public String toString() {
        return "WithdrawCash{" +
                "acountType='" + acountType + '\'' +
                ", acountTypeCode='" + acountTypeCode + '\'' +
                ", accountNumber='" + accountNumber + '\'' +
                ", currentBalance=" + currentBalance +
                ", requestedAmount=" + requestedAmount +
                ", previousBalance=" + previousBalance +
                '}';
    }

}
