package co.za.discovery.banking.DiscoveryATM.model;

import javax.persistence.*;
import java.util.Set;

@Entity
@Table (name = "DENOMINATION_TYPE")
public class DenominationType {

    @Id
    @Column (name = "DENOMINATION_TYPE_CODE", nullable = false)
    private String denominationTypeCode;

    @Column (name = "DESCRIPTION", nullable = false)
    private String description;

    @OneToMany(fetch = FetchType.EAGER, cascade = CascadeType.ALL, mappedBy = "denominationType")
    private Set<Denomination> denominations;

    public String getDenominationTypeCode() {
        return denominationTypeCode;
    }

    public void setDenominationTypeCode(String denominationTypeCode) {
        this.denominationTypeCode = denominationTypeCode;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Set<Denomination> getDenominations() {
        return denominations;
    }

    public void setDenominations(Set<Denomination> denominations) {
        this.denominations = denominations;
    }
}
