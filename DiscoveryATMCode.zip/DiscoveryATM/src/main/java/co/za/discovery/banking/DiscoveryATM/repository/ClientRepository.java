package co.za.discovery.banking.DiscoveryATM.repository;

import co.za.discovery.banking.DiscoveryATM.model.Client;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ClientRepository extends JpaRepository<Client, Integer> {

    Client findClientByClientID(Integer clientID);
}
