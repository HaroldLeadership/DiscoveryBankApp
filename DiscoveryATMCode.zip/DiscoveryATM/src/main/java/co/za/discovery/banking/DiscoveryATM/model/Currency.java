package co.za.discovery.banking.DiscoveryATM.model;

import javax.persistence.*;

@Entity
@Table(name = "CURRENCY")
public class Currency {

    @Id
    @Column(name = "CURRENCY_CODE", nullable = false)
    private String currencyCode;
    @Column(name = "DECIMAL_PLACES", nullable = false)
    private Integer decimalPlaces;
    @Column(name = "DESCRIPTION", nullable = false)
    private String description;

    @OneToOne(fetch = FetchType.LAZY, cascade = CascadeType.ALL, mappedBy = "currency")
    private ClientAccount clientCurrencyAccount;

    @OneToOne(optional=false)
    @JoinColumn(name = "CURRENCY_CODE", insertable=false, updatable=false)
    private CurrencyConversionRate conversionRate;

    public String getCurrencyCode() {
        return currencyCode;
    }

    public void setCurrencyCode(String currencyCode) {
        this.currencyCode = currencyCode;
    }

    public Integer getDecimalPlaces() {
        return decimalPlaces;
    }

    public void setDecimalPlaces(Integer decimalPlaces) {
        this.decimalPlaces = decimalPlaces;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public ClientAccount getClientCurrencyAccount() {
        return clientCurrencyAccount;
    }

    public void setClientCurrencyAccount(ClientAccount clientCurrencyAccount) {
        this.clientCurrencyAccount = clientCurrencyAccount;
    }

    public CurrencyConversionRate getConversionRate() {
        return conversionRate;
    }

    public void setConversionRate(CurrencyConversionRate conversionRate) {
        this.conversionRate = conversionRate;
    }

    @Override
    public String toString() {
        return "Currency{" +
                "currencyCode='" + currencyCode + '\'' +
                ", decimalPlaces=" + decimalPlaces +
                ", description='" + description + '\'' +
                ", conversionRate=" + conversionRate +
                '}';
    }
}
