package co.za.discovery.banking.DiscoveryATM.service;

import co.za.discovery.banking.DiscoveryATM.model.*;
import co.za.discovery.banking.DiscoveryATM.pojo.Denomination;
import co.za.discovery.banking.DiscoveryATM.pojo.WithdrawCash;
import co.za.discovery.banking.DiscoveryATM.pojo.Account;
import co.za.discovery.banking.DiscoveryATM.repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Service
public class BankAppServiceImpl implements BankAppService {

    @Autowired
    private ClientRepository clientRepository;
    @Autowired
    private ClientAccountRepository clientAccountRepository;
    @Autowired
    private ATMRepository atmRepository;
    @Autowired
    private CreditCardLimitRepository creditCardLimitRepository;
    @Autowired
    private ATMAllocationRepository atmAllocationRepository;

    private static final SimpleDateFormat sdf = new SimpleDateFormat("yyyy.MM.dd.HH.mm.ss");

    public List <ATM> getATMList (){
        List <ATM> atmList = atmRepository.findAll();

        return  atmList;
    }

    public ATM getATM (int atmID){
        return  atmRepository.findATMByAtmID(atmID);
    }

    public List<ATMAllocation> getATMAllocation(int atmID){
        return atmAllocationRepository.findAllByAtmID(atmID);
    }

    public List <Account> getClientCurrencyAccount (Login login){
        List<ClientAccount> clientCurrencyAccountList = clientAccountRepository.findAllByClientIDOrderByDisplayBalance(stringToInteger(login.getClientID()));
        List<Account> accountList = new ArrayList<>();
        Account accountDetails;

        for (ClientAccount clientAccount : clientCurrencyAccountList) {
            if (clientAccount.getAccountType().getTransactional() != 1 &
                    clientAccount.getAccountType().getAccountTypeCode().equals("CFCA")) {
                accountDetails = new Account();
                accountDetails.setAccountNumber(clientAccount.getClientAccountNumber());
                accountDetails.setCurrency(clientAccount.getCurrencyCode());
                accountDetails.setAccBalance(clientAccount.getDisplayBalance());
                accountDetails.setConversionRate(clientAccount.getCurrency().getConversionRate().getRate());
                accountDetails.setZARAmount(calculateAmount(clientAccount.getCurrency().getConversionRate().getRate(),
                        clientAccount.getDisplayBalance(), clientAccount.getCurrency().getDecimalPlaces()));

                accountList.add(accountDetails);
            }
        }

        return accountList;
    }

    public List<Account> getClientTransactionalAccount(Login login){
        List<ClientAccount> clientTransactionalAccountList = clientAccountRepository.findAllByClientIDOrderByDisplayBalance(stringToInteger(login.getClientID()));
        List<Account> clientAccountsList = new ArrayList<>();
        Account accountDetails;

        for (ClientAccount clientAccount : clientTransactionalAccountList) {
            if (clientAccount.getAccountType().getTransactional() == 1) {
                accountDetails = new Account();
                accountDetails.setAccountNumber(clientAccount.getClientAccountNumber());
                accountDetails.setAccType(clientAccount.getAccountType().getDescription());
                accountDetails.setAccBalance(clientAccount.getDisplayBalance());
                clientAccountsList.add(accountDetails);
            }
        }

        return clientAccountsList;
    }

    public WithdrawCash cashWithdrawal(WithdrawCash withdrawCash, ATM atm){
        WithdrawCash updatedAccount;
        Double previousBalance = withdrawCash.getCurrentBalance();
        Double requestedAmount = withdrawCash.getRequestedAmount();
        String accountNumber = withdrawCash.getAccountNumber();
        Double balance = roundOffAmount(withdrawCash.getCurrentBalance() - withdrawCash.getRequestedAmount());

        Denomination denomination = calculateNoOfNotes(atm.getAtmID(), doubleToInt(requestedAmount));
        Integer [] numberOfNotes = denomination.getLowestNotes();
        int [] count = denomination.getCountNotes();
        for (int i = 0; i < numberOfNotes.length; i++){
            atmAllocationRepository.updateATMAllocation((count[i]-numberOfNotes[i]), atm.getAtmID(), i+1);
        }

        clientAccountRepository.updateClientAccount(balance, accountNumber);
        updatedAccount = getClientAccount (accountNumber);
        updatedAccount.setPreviousBalance(previousBalance);
        updatedAccount.setNotes(computeNotes(denomination));
        updatedAccount.setTimestamp(getCurrentTimeStamp());

        return updatedAccount;
    }

    public String computeNotes(Denomination denomination){
        StringBuilder notes = new StringBuilder();
        int currDenom[] = denomination.getDenomination();
        Integer currNo [] = denomination.getLowestNotes();

        for (int k = 0; k < currDenom.length; k++){

            if(currNo[k] != 0)
                notes.append(currNo[k] + "(R" +currDenom[k] + ".00)" + " ");
        }
        System.out.println("\nStringBuilder Notes : " +notes.toString() + "\n");
        return notes.toString();
    }

    public WithdrawCash getClientAccount(String accountNumber){
        ClientAccount clientAccount = clientAccountRepository.findClientAccountByClientAccountNumber(accountNumber);

        WithdrawCash account = new WithdrawCash();
        account.setAccountNumber(clientAccount.getClientAccountNumber());
        account.setAcountType(clientAccount.getAccountType().getDescription());
        account.setAcountTypeCode(clientAccount.getAccountTypeCode());
        account.setCurrentBalance(clientAccount.getDisplayBalance());

        return account;
    }

    public boolean checkCreditLimit (String accountNumber, Double requestedAmount){
        CreditCardLimit creditCardLimit = creditCardLimitRepository.findCreditCardLimitByClientAccountNumber(accountNumber);
        Double creditLimit = creditCardLimit.getAccountLimit();

        if(requestedAmount >= creditLimit){
            return true;
        }
        return false;
    }

    public Double calcTotalNotes (int atmID){
        Double availableCash = 0.00;
        List<ATMAllocation> atmAllocation = getATMAllocation(atmID);

        for (ATMAllocation allocation : atmAllocation) {
            availableCash = availableCash + allocation.getCount() * allocation.getDenomination().getValue();
        }
        return roundOffAmount(availableCash);
    }

    public Denomination calculateNoOfNotes (int atmID, int amount){
        List<ATMAllocation> atmAllocation = getATMAllocation(atmID);
        int currDenom[] = new int[atmAllocation.size()];
        int currNo [] = new int[atmAllocation.size()];
        int i = 0;

        for (ATMAllocation allocation : atmAllocation) {
            currDenom[i] = doubleToInt(allocation.getDenomination().getValue());
            currNo[i] = allocation.getCount();
            i++;
        }

        List<Integer[]> results = WithDrawService.getInstance().determineDenomination(currDenom, currNo, new int[5], amount, 0);
        Integer [] lowestNotes = WithDrawService.getInstance().getLowestNotes(results, currDenom.length);

        Denomination denomination = new Denomination();
        denomination.setCountNotes(currNo);
        denomination.setDenomination(currDenom);
        denomination.setLowestNotes(lowestNotes);

        return denomination;
    }

    public Timestamp getCurrentTimeStamp (){
        Date date = new Date();
        return new Timestamp(date.getTime());
    }

    public double calculateAmount(double balance, double rate, int places){
        double amount = balance * rate;
        double scale = Math.pow(10, places);
        return Math.round(amount * scale) / scale;
    }

    public double roundOffAmount(double balance){
        double scale = Math.pow(10, 2);
        return Math.round(balance * scale) / scale;
    }

    public boolean authenticate(Login login){
        String clientNumber = login.getClientID().trim();
        if("".equals(clientNumber)){
            return false;
        }

        Client client = clientRepository.findClientByClientID(stringToInteger(clientNumber));
        if(client == null)
            return false;

        return true;
    }

    protected Integer stringToInteger(String parameter){
        return Integer.parseInt(parameter);
    }

    protected int doubleToInt(Double value){
        return (int) Math.round(value);
    }
}
