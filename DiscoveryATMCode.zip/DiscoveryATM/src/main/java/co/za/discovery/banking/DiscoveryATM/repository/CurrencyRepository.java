package co.za.discovery.banking.DiscoveryATM.repository;

import co.za.discovery.banking.DiscoveryATM.model.Currency;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CurrencyRepository extends JpaRepository<Currency, Integer> {
}
