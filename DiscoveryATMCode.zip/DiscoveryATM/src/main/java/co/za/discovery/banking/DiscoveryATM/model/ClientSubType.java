package co.za.discovery.banking.DiscoveryATM.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "CLIENT_SUB_TYPE")
public class ClientSubType {

    @Id
    @Column(name = "CLIENT_SUB_TYPE_CODE", nullable = false)
    private String clientSubTypeCode;
    @Column(name = "CLIENT_TYPE_CODE", nullable = false)
    private String clientTypeCode;
    @Column(name = "DESCRIPTION", nullable = false)
    private String description;

    public String getClientSubTypeCode() {
        return clientSubTypeCode;
    }

    public void setClientSubTypeCode(String clientSubTypeCode) {
        this.clientSubTypeCode = clientSubTypeCode;
    }

    public String getClientTypeCode() {
        return clientTypeCode;
    }

    public void setClientTypeCode(String clientTypeCode) {
        this.clientTypeCode = clientTypeCode;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
}
