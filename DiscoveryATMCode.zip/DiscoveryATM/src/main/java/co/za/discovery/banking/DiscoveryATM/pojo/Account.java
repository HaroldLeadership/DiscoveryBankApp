package co.za.discovery.banking.DiscoveryATM.pojo;

public class Account {

    private String accountNumber;
    private String accType;
    private Double accBalance;
    private String currency;
    private Double conversionRate;
    private Double ZARAmount;

    public Account(){}

    public Account(String accountNumber, String accType, Double accBalance, String currency, Double conversionRate, Double ZARAmount) {
        this.accountNumber = accountNumber;
        this.accType = accType;
        this.accBalance = accBalance;
        this.currency = currency;
        this.conversionRate = conversionRate;
        this.ZARAmount = ZARAmount;
    }

    public String getAccountNumber() {
        return accountNumber;
    }

    public void setAccountNumber(String accountNumber) {
        this.accountNumber = accountNumber;
    }

    public String getAccType() {
        return accType;
    }

    public void setAccType(String accType) {
        this.accType = accType;
    }

    public Double getAccBalance() {
        return accBalance;
    }

    public void setAccBalance(Double accBalance) {
        this.accBalance = accBalance;
    }

    public String getCurrency() {
        return currency;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }

    public Double getConversionRate() {
        return conversionRate;
    }

    public void setConversionRate(Double conversionRate) {
        this.conversionRate = conversionRate;
    }

    public Double getZARAmount() {
        return ZARAmount;
    }

    public void setZARAmount(Double ZARAmount) {
        this.ZARAmount = ZARAmount;
    }
}
