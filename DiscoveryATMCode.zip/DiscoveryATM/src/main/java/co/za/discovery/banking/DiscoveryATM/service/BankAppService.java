package co.za.discovery.banking.DiscoveryATM.service;

import co.za.discovery.banking.DiscoveryATM.model.Login;
import co.za.discovery.banking.DiscoveryATM.pojo.WithdrawCash;
import co.za.discovery.banking.DiscoveryATM.pojo.Account;

import java.util.List;

public interface BankAppService {
    List <Account> getClientCurrencyAccount (Login login);
    List <Account> getClientTransactionalAccount(Login login);
    WithdrawCash getClientAccount(String accountNumber);
}
