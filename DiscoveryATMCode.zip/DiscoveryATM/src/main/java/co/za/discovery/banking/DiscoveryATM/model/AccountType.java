package co.za.discovery.banking.DiscoveryATM.model;

import javax.persistence.*;

@Entity
@Table(name = "ACCOUNT_TYPE")
public class AccountType {

    @Id
    @Column(name = "ACCOUNT_TYPE_CODE", nullable = false)
    private String accountTypeCode;
    @Column(name = "DESCRIPTION", nullable = false)
    private String description;
    @Column(name = "TRANSACTIONAL", nullable = true)
    private int transactional;

    @OneToOne(fetch = FetchType.LAZY, cascade = CascadeType.ALL, mappedBy = "accountType")
    private ClientAccount clientAccount;

    /*@OneToOne(fetch = FetchType.LAZY, cascade = CascadeType.ALL, optional=false)
    @JoinColumn(name = "ACCOUNT_TYPE_CODE", referencedColumnName = "ACCOUNT_TYPE_CODE",nullable = false, insertable=false, updatable=false)
    private ClientAccount clientAccount;*/

    public String getAccountTypeCode() {
        return accountTypeCode;
    }

    public void setAccountTypeCode(String accountTypeCode) {
        this.accountTypeCode = accountTypeCode;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public int getTransactional() {
        return transactional;
    }

    public void setTransactional(int transactional) {
        this.transactional = transactional;
    }

    public ClientAccount getClientAccount() {
        return clientAccount;
    }

    public void setClientAccount(ClientAccount clientAccount) {
        this.clientAccount = clientAccount;
    }

    @Override
    public String toString() {
        return "AccountType{" +
                "accountTypeCode='" + accountTypeCode + '\'' +
                ", description='" + description + '\'' +
                ", transactional=" + transactional +
                '}';
    }
}
