package co.za.discovery.banking.DiscoveryATM.model;

import javax.persistence.*;
import java.util.Set;

@Entity
@Table(name = "ATM")
public class ATM {

    @Id
    @Column (name = "ATM_ID")
    private int atmID;
    @Column (name = "NAME")
    private String name;
    @Column (name = "LOCATION")
    private String location;

    @OneToMany(fetch = FetchType.EAGER, cascade = CascadeType.ALL, mappedBy = "atm")
    private Set<ATMAllocation> atmAllocations;

    public int getAtmID() {
        return atmID;
    }

    public void setAtmID(int atmID) {
        this.atmID = atmID;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public Set<ATMAllocation> getAtmAllocations() {
        return atmAllocations;
    }

    public void setAtmAllocations(Set<ATMAllocation> atmAllocations) {
        this.atmAllocations = atmAllocations;
    }

    @Override
    public String toString() {
        return "ATM{" +
                "atmID=" + atmID +
                ", name='" + name + '\'' +
                ", location='" + location + '\'' +
                '}';
    }
}
