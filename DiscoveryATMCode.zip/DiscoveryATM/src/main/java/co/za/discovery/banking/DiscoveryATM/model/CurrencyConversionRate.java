package co.za.discovery.banking.DiscoveryATM.model;

import javax.persistence.*;

@Entity
@Table(name = "CURRENCY_CONVERSION_RATE")
public class CurrencyConversionRate {

    @Id
    @Column(name = "CURRENCY_CODE", nullable = false)
    private String currecyCode;
    @Column(name = "CONVERSION_INDICATOR", nullable = false)
    private String conversionIndicator;
    @Column(name = "RATE", nullable = false)
    private Double rate;

    @OneToOne(optional=false)
    @JoinColumn(name = "CURRENCY_CODE", insertable=false, updatable=false)
    private Currency currency;

    public String getCurrecyCode() {
        return currecyCode;
    }

    public void setCurrecyCode(String currecyCode) {
        this.currecyCode = currecyCode;
    }

    public String getConversionIndicator() {
        return conversionIndicator;
    }

    public void setConversionIndicator(String conversionIndicator) {
        this.conversionIndicator = conversionIndicator;
    }

    public Double getRate() {
        return rate;
    }

    public void setRate(Double rate) {
        this.rate = rate;
    }

    public Currency getCurrency() {
        return currency;
    }

    public void setCurrency(Currency currency) {
        this.currency = currency;
    }

    @Override
    public String toString() {
        return "CurrencyConversionRate{" +
                "currecyCode='" + currecyCode + '\'' +
                ", conversionIndicator='" + conversionIndicator + '\'' +
                ", rate=" + rate +
                //", currency=" + currency +
                '}';
    }
}
