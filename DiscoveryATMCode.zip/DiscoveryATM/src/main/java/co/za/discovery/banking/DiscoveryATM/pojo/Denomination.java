package co.za.discovery.banking.DiscoveryATM.pojo;

import java.util.Arrays;

public class Denomination {
    Integer [] lowestNotes;
    int [] countNotes;
    int [] denomination;

    public Integer[] getLowestNotes() {
        return lowestNotes;
    }

    public void setLowestNotes(Integer[] lowestNotes) {
        this.lowestNotes = lowestNotes;
    }

    public int[] getCountNotes() {
        return countNotes;
    }

    public void setCountNotes(int[] countNotes) {
        this.countNotes = countNotes;
    }

    public int[] getDenomination() {
        return denomination;
    }

    public void setDenomination(int[] denomination) {
        this.denomination = denomination;
    }

    @Override
    public String toString() {
        return "Denomination{" +
                "lowestNotes=" + Arrays.toString(lowestNotes) +
                ", countNotes=" + Arrays.toString(countNotes) +
                ", denomination=" + Arrays.toString(denomination) +
                '}';
    }
}
