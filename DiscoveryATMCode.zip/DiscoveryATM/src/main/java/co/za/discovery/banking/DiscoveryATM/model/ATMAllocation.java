package co.za.discovery.banking.DiscoveryATM.model;

import javax.persistence.*;

@Entity
@Table (name = "ATM_ALLOCATION")
public class ATMAllocation {

    @Id
    @Column (name = "ATM_ALLOCATION_ID")
    private int atmAllocationID;
    @Column (name = "ATM_ID")
    private int atmID;
    @Column (name = "DENOMINATION_ID")
    private int denominationID;
    @Column (name = "COUNT")
    private int count;

    @ManyToOne
    @JoinColumn (name = "ATM_ID", nullable = false,insertable = false, updatable = false)
    private ATM atm;

    @ManyToOne
    @JoinColumn (name = "DENOMINATION_ID", nullable = false,insertable = false, updatable = false)
    private Denomination denomination;

    public int getAtmAllocationID() {
        return atmAllocationID;
    }

    public void setAtmAllocationID(int atmAllocationID) {
        this.atmAllocationID = atmAllocationID;
    }

    public int getAtmID() {
        return atmID;
    }

    public void setAtmID(int atmID) {
        this.atmID = atmID;
    }

    public int getDenominationID() {
        return denominationID;
    }

    public void setDenominationID(int denominationID) {
        this.denominationID = denominationID;
    }

    public int getCount() {
        return count;
    }

    public void setCount(int count) {
        this.count = count;
    }

    public ATM getAtm() {
        return atm;
    }

    public void setAtm(ATM atm) {
        this.atm = atm;
    }

    public Denomination getDenomination() {
        return denomination;
    }

    public void setDenomination(Denomination denomination) {
        this.denomination = denomination;
    }

    @Override
    public String toString() {
        return "ATMAllocation{" +
                "atmAllocationID=" + atmAllocationID +
                ", atmID=" + atmID +
                ", denominationID=" + denominationID +
                ", count=" + count +
                '}';
    }
}
