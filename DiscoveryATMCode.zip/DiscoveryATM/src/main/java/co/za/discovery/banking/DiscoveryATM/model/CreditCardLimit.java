package co.za.discovery.banking.DiscoveryATM.model;

import javax.persistence.*;

@Entity
@Table(name = "CREDIT_CARD_LIMIT")
public class CreditCardLimit {

    @Id
    @Column(name = "CLIENT_ACCOUNT_NUMBER", nullable = false)
    private String clientAccountNumber;
    @Column(name = "ACCOUNT_LIMIT", nullable = false)
    private Double accountLimit;

    @OneToOne(fetch = FetchType.LAZY, cascade = CascadeType.ALL, mappedBy = "creditCardLimit")
    private ClientAccount clientCurrencyAccount;

    public String getClientAccountNumber() {
        return clientAccountNumber;
    }

    public void setClientAccountNumber(String clientAccountNumber) {
        this.clientAccountNumber = clientAccountNumber;
    }

    public Double getAccountLimit() {
        return accountLimit;
    }

    public void setAccountLimit(Double accountLimit) {
        this.accountLimit = accountLimit;
    }

    public ClientAccount getClientCurrencyAccount() {
        return clientCurrencyAccount;
    }

    public void setClientCurrencyAccount(ClientAccount clientCurrencyAccount) {
        this.clientCurrencyAccount = clientCurrencyAccount;
    }
}
