package co.za.discovery.banking.DiscoveryATM.pojo;

public class Errors {

    private String errorMessage;

    public String getErrorMessage() {
        return errorMessage;
    }

    public void setErrorMessage(String errorMessage) {
        this.errorMessage = errorMessage;
    }

    @Override
    public String toString() {
        return "Errors{" +
                "errorMessage='" + errorMessage + '\'' +
                '}';
    }
}
