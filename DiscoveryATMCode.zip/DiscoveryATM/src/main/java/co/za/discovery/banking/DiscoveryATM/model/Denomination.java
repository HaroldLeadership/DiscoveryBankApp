package co.za.discovery.banking.DiscoveryATM.model;

import javax.persistence.*;
import java.util.Set;

@Entity
@Table (name = "DENOMINATION")
public class Denomination {

    @Id
    @Column (name = "DENOMINATION_ID", nullable = false)
    private int denominationID;
    @Column (name = "VALUE", nullable = false)
    private Double value;
    @Column (name = "DENOMINATION_TYPE_CODE", nullable = true)
    private String denominationTypeCode;

    @ManyToOne
    @JoinColumn (name = "DENOMINATION_TYPE_CODE", nullable = false,insertable = false, updatable = false)
    private DenominationType denominationType;

    @OneToMany(fetch = FetchType.EAGER, cascade = CascadeType.ALL, mappedBy = "denomination")
    private Set<ATMAllocation> atmAllocations;

    public int getDenominationID() {
        return denominationID;
    }

    public void setDenominationID(int denominationID) {
        this.denominationID = denominationID;
    }

    public Double getValue() {
        return value;
    }

    public void setValue(Double value) {
        this.value = value;
    }

    public String getDenominationTypeCode() {
        return denominationTypeCode;
    }

    public void setDenominationTypeCode(String denominationTypeCode) {
        this.denominationTypeCode = denominationTypeCode;
    }

    public DenominationType getDenominationType() {
        return denominationType;
    }

    public void setDenominationType(DenominationType denominationType) {
        this.denominationType = denominationType;
    }

    public Set<ATMAllocation> getAtmAllocations() {
        return atmAllocations;
    }

    public void setAtmAllocations(Set<ATMAllocation> atmAllocations) {
        this.atmAllocations = atmAllocations;
    }
}
